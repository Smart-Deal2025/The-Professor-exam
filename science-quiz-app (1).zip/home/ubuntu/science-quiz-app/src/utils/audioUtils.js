// Audio utility functions for the quiz app

// Create audio context for generating simple sounds
const audioContext = new (window.AudioContext || window.webkitAudioContext)()

// Function to play a simple click sound when answering questions
export const playAnswerSound = () => {
  try {
    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()
    
    oscillator.connect(gainNode)
    gainNode.connect(audioContext.destination)
    
    oscillator.frequency.setValueAtTime(800, audioContext.currentTime)
    oscillator.frequency.exponentialRampToValueAtTime(600, audioContext.currentTime + 0.1)
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1)
    
    oscillator.start(audioContext.currentTime)
    oscillator.stop(audioContext.currentTime + 0.1)
  } catch (error) {
    console.log('Audio not supported or blocked')
  }
}

// Function to play success sound for high scores (>70%)
export const playSuccessSound = () => {
  try {
    // Play a celebratory melody
    const notes = [523.25, 659.25, 783.99, 1046.50] // C5, E5, G5, C6
    const noteDuration = 0.2
    
    notes.forEach((frequency, index) => {
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()
      
      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)
      
      oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime + index * noteDuration)
      oscillator.type = 'sine'
      
      gainNode.gain.setValueAtTime(0, audioContext.currentTime + index * noteDuration)
      gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + index * noteDuration + 0.01)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + index * noteDuration + noteDuration - 0.01)
      
      oscillator.start(audioContext.currentTime + index * noteDuration)
      oscillator.stop(audioContext.currentTime + index * noteDuration + noteDuration)
    })
  } catch (error) {
    console.log('Audio not supported or blocked')
  }
}

// Function to speak congratulations message using Web Speech API
export const speakCongratulations = () => {
  try {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance('أحسنت أيها البطل، طلاب البروفيسير دائماً في المقدمة')
      utterance.lang = 'ar-SA'
      utterance.rate = 0.8
      utterance.pitch = 1.2
      utterance.volume = 0.8
      
      // Try to find an Arabic voice
      const voices = speechSynthesis.getVoices()
      const arabicVoice = voices.find(voice => voice.lang.includes('ar'))
      if (arabicVoice) {
        utterance.voice = arabicVoice
      }
      
      speechSynthesis.speak(utterance)
    }
  } catch (error) {
    console.log('Speech synthesis not supported or blocked')
  }
}

// Initialize audio context on user interaction
export const initializeAudio = () => {
  if (audioContext.state === 'suspended') {
    audioContext.resume()
  }
}

