import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog.jsx'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Clock, FileText, CheckCircle, XCircle, Award, ArrowLeft, ArrowRight, User, GraduationCap, Home } from 'lucide-react'
import { playAnswerSound, playSuccessSound, speakCongratulations, initializeAudio } from '../utils/audioUtils.js'

const StudentInterface = ({ questions, exams, onSubmitResult, onBackToHome }) => {
  const [selectedGrade, setSelectedGrade] = useState('first') // 'first', 'second', 'third'
  const [studentName, setStudentName] = useState('') // New state for student name
  const [showNameDialog, setShowNameDialog] = useState(false) // Dialog for entering name
  const [showPasswordDialog, setShowPasswordDialog] = useState(false) // Dialog for entering password
  const [examPassword, setExamPassword] = useState('') // Password input
  const [currentExam, setCurrentExam] = useState(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answers, setAnswers] = useState({})
  const [timeRemaining, setTimeRemaining] = useState(0)
  const [examStarted, setExamStarted] = useState(false)
  const [examCompleted, setExamCompleted] = useState(false)
  const [examResult, setExamResult] = useState(null)
  const [showResultDialog, setShowResultDialog] = useState(false)
  const [shuffledQuestions, setShuffledQuestions] = useState([]) // لحفظ الأسئلة مع الخيارات المرتبة عشوائياً

  // دالة لترتيب مصفوفة عشوائياً (Fisher-Yates shuffle)
  const shuffleArray = (array) => {
    const shuffled = [...array]
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]
    }
    return shuffled
  }

  // دالة لترتيب خيارات السؤال عشوائياً مع تتبع الإجابة الصحيحة
  const shuffleQuestionOptions = (question) => {
    const optionsWithIndex = question.options.map((option, index) => ({
      text: option,
      originalIndex: index
    }))
    
    const shuffledOptions = shuffleArray(optionsWithIndex)
    const newCorrectAnswer = shuffledOptions.findIndex(
      option => option.originalIndex === question.correctAnswer
    )
    
    return {
      ...question,
      options: shuffledOptions.map(option => option.text),
      correctAnswer: newCorrectAnswer,
      originalCorrectAnswer: question.correctAnswer // نحتفظ بالإجابة الأصلية للمراجعة
    }
  }

  // Timer effect
  useEffect(() => {
    let timer
    if (examStarted && timeRemaining > 0 && !examCompleted) {
      timer = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            handleSubmitExam()
            return 0
          }
          return prev - 1
        })
      }, 1000)
    }
    return () => clearInterval(timer)
  }, [examStarted, timeRemaining, examCompleted])

  const startExam = (exam) => {
    if (!studentName.trim()) {
      setShowNameDialog(true)
      setCurrentExam(exam) // Store exam to start after name is entered
      return
    }
    
    // Check if exam has password
    if (exam.password && exam.password.trim()) {
      setShowPasswordDialog(true)
      setCurrentExam(exam) // Store exam to start after password is verified
      setExamPassword('')
      return
    }
    
    // Start exam directly if no password required
    startExamDirectly(exam)
  }

  const startExamDirectly = (exam) => {
    // ترتيب خيارات الأسئلة عشوائياً
    const examQuestions = questions.filter(q => exam.questions?.includes(q.id) || exam.questionIds?.includes(q.id))
    const shuffledExamQuestions = examQuestions.map(question => shuffleQuestionOptions(question))
    
    setShuffledQuestions(shuffledExamQuestions)
    setCurrentExam(exam)
    setCurrentQuestionIndex(0)
    setAnswers({})
    setTimeRemaining(exam.duration * 60) // Convert minutes to seconds
    setExamStarted(true)
    setExamCompleted(false)
    setExamResult(null)
  }

  const handlePasswordSubmit = () => {
    if (currentExam && examPassword === currentExam.password) {
      setShowPasswordDialog(false)
      setExamPassword('')
      startExamDirectly(currentExam)
    } else {
      alert('كلمة السر غير صحيحة')
    }
  }

  const handleNameSubmit = () => {
    if (studentName.trim() && currentExam) {
      setShowNameDialog(false)
      
      // Check if exam has password after name is entered
      if (currentExam.password && currentExam.password.trim()) {
        setShowPasswordDialog(true)
        setExamPassword('')
        return
      }
      
      // Start exam directly if no password required
      startExamDirectly(currentExam)
    }
  }

  const handleAnswerChange = (questionId, answerIndex) => {
    // Initialize audio context on first interaction
    initializeAudio()
    
    // Play answer sound
    playAnswerSound()
    
    setAnswers(prev => ({
      ...prev,
      [questionId]: answerIndex
    }))
  }

  const handleSubmitExam = () => {
    if (!currentExam || shuffledQuestions.length === 0) return

    let correctCount = 0
    const detailedAnswers = []

    shuffledQuestions.forEach(question => {
      const studentAnswer = answers[question.id]
      const isCorrect = studentAnswer === question.correctAnswer
      if (isCorrect) correctCount++
      
      detailedAnswers.push({
        questionId: question.id,
        questionText: question.text,
        studentAnswer,
        correctAnswer: question.correctAnswer,
        originalCorrectAnswer: question.originalCorrectAnswer,
        options: question.options,
        isCorrect
      })
    })

    const score = Math.round((correctCount / shuffledQuestions.length) * 100)
    const timeSpent = Math.round((currentExam.duration * 60 - timeRemaining) / 60)

    const result = {
      id: Date.now(),
      studentName: studentName, // Use the entered student name
      examTitle: currentExam.title,
      score,
      totalQuestions: shuffledQuestions.length,
      correctAnswers: correctCount,
      completedAt: new Date().toISOString(),
      timeSpent,
      answers: detailedAnswers
    }

    setExamResult(result)
    setExamCompleted(true)
    setExamStarted(false)
    setShowResultDialog(true)
    
    // Play success sound and congratulations for scores > 70%
    if (score > 70) {
      setTimeout(() => {
        playSuccessSound()
        setTimeout(() => {
          speakCongratulations()
        }, 800) // Wait for success sound to finish
      }, 500) // Small delay to let dialog appear
    }
    
    onSubmitResult(result)
  }

  const resetExam = () => {
    setCurrentExam(null)
    setCurrentQuestionIndex(0)
    setAnswers({})
    setTimeRemaining(0)
    setExamStarted(false)
    setExamCompleted(false)
    setExamResult(null)
    setShowResultDialog(false)
  }

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`
  }

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600'
    if (score >= 80) return 'text-blue-600'
    if (score >= 70) return 'text-yellow-600'
    if (score >= 60) return 'text-orange-600'
    return 'text-red-600'
  }

  const getScoreBadge = (score) => {
    if (score >= 90) return { variant: 'default', text: 'ممتاز', icon: '🏆' }
    if (score >= 80) return { variant: 'secondary', text: 'جيد جداً', icon: '🥈' }
    if (score >= 70) return { variant: 'outline', text: 'جيد', icon: '🥉' }
    if (score >= 60) return { variant: 'secondary', text: 'مقبول', icon: '✅' }
    return { variant: 'destructive', text: 'ضعيف', icon: '❌' }
  }

  // If exam is in progress
  if (examStarted && currentExam && shuffledQuestions.length > 0) {
    const currentQuestion = shuffledQuestions[currentQuestionIndex]
    const progress = ((currentQuestionIndex + 1) / shuffledQuestions.length) * 100

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto p-6">
          {/* Exam Header */}
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{currentExam.title}</h1>
                <p className="text-gray-600">السؤال {currentQuestionIndex + 1} من {shuffledQuestions.length}</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 text-lg font-semibold">
                  <Clock className="h-5 w-5" />
                  <span className={timeRemaining < 300 ? 'text-red-600' : 'text-gray-900'}>
                    {formatTime(timeRemaining)}
                  </span>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={progress} className="h-2" />
            </div>
          </div>

          {/* Question Card */}
          <Card className="mb-6">
            <CardHeader>
              {currentQuestion.questionType === 'image' ? (
                <div>
                  <img 
                    src={currentQuestion.imageUrl} 
                    alt="سؤال مصور" 
                    className="max-w-full h-64 object-contain border rounded mb-4 mx-auto"
                  />
                  {currentQuestion.text && (
                    <CardTitle className="text-xl">{currentQuestion.text}</CardTitle>
                  )}
                </div>
              ) : (
                <CardTitle className="text-xl">{currentQuestion.text}</CardTitle>
              )}
            </CardHeader>
            <CardContent>
              <RadioGroup
                value={answers[currentQuestion.id]?.toString()}
                onValueChange={(value) => handleAnswerChange(currentQuestion.id, parseInt(value))}
              >
                {currentQuestion.options.map((option, index) => (
                  <div key={index} className="flex items-center space-x-2 space-x-reverse p-3 rounded-lg border hover:bg-gray-50">
                    <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                    <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                      {option}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
              disabled={currentQuestionIndex === 0}
            >
              <ArrowRight className="h-4 w-4 mr-2" />
              السؤال السابق
            </Button>

            <div className="flex gap-2">
              {currentQuestionIndex === shuffledQuestions.length - 1 ? (
                <Button onClick={handleSubmitExam} className="bg-green-600 hover:bg-green-700">
                  إنهاء الاختبار
                </Button>
              ) : (
                <Button
                  onClick={() => setCurrentQuestionIndex(prev => Math.min(shuffledQuestions.length - 1, prev + 1))}
                >
                  السؤال التالي
                  <ArrowLeft className="h-4 w-4 ml-2" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Main student interface
  return (
    <div className="container mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              البروفيسير في العلوم
            </h1>
            <p className="text-gray-600">واجهة الطالب - اختر الاختبار المناسب وابدأ</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onBackToHome}>
              <Home className="h-4 w-4 mr-2" />
              الصفحة الرئيسية
            </Button>
          </div>
        </div>
      </div>

      {/* Available Exams */}
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">الاختبارات المتاحة</h2>
          <div className="flex items-center gap-3">
            <img 
              src="/teacher-avatar.png" 
              alt="صورة المعلم" 
              className="w-12 h-12 rounded-full border-2 border-blue-200"
            />
            <div className="text-sm">
              <p className="font-medium">أستاذ العلوم</p>
              <p className="text-gray-500">مرحباً بكم في منصة الاختبارات</p>
            </div>
          </div>
        </div>
        
        <Tabs value={selectedGrade} onValueChange={setSelectedGrade} className="w-full">
          <TabsList className="grid w-full grid-cols-4 h-auto p-2 bg-white rounded-xl shadow-sm border">
            <TabsTrigger 
              value="first" 
              className="flex flex-col items-center gap-2 p-4 rounded-lg data-[state=active]:bg-blue-500 data-[state=active]:text-white transition-all duration-200 hover:bg-blue-50"
            >
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 data-[state=active]:bg-white data-[state=active]:text-blue-500">
                <GraduationCap className="h-6 w-6" />
              </div>
              <span className="text-sm font-medium">الأول الإعدادي</span>
            </TabsTrigger>
            <TabsTrigger 
              value="second" 
              className="flex flex-col items-center gap-2 p-4 rounded-lg data-[state=active]:bg-green-500 data-[state=active]:text-white transition-all duration-200 hover:bg-green-50"
            >
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-100 data-[state=active]:bg-white data-[state=active]:text-green-500">
                <GraduationCap className="h-6 w-6" />
              </div>
              <span className="text-sm font-medium">الثاني الإعدادي</span>
            </TabsTrigger>
            <TabsTrigger 
              value="third" 
              className="flex flex-col items-center gap-2 p-4 rounded-lg data-[state=active]:bg-purple-500 data-[state=active]:text-white transition-all duration-200 hover:bg-purple-50"
            >
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-purple-100 data-[state=active]:bg-white data-[state=active]:text-purple-500">
                <GraduationCap className="h-6 w-6" />
              </div>
              <span className="text-sm font-medium">الثالث الإعدادي</span>
            </TabsTrigger>
            <TabsTrigger 
              value="firstSecondary" 
              className="flex flex-col items-center gap-2 p-4 rounded-lg data-[state=active]:bg-orange-500 data-[state=active]:text-white transition-all duration-200 hover:bg-orange-50"
            >
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-orange-100 data-[state=active]:bg-white data-[state=active]:text-orange-500">
                <GraduationCap className="h-6 w-6" />
              </div>
              <span className="text-sm font-medium">الأول الثانوي</span>
            </TabsTrigger>
          </TabsList>
          
          {["first", "second", "third", "firstSecondary"].map((grade) => {
            const gradeMapping = {
              first: "الأول الإعدادي",
              second: "الثاني الإعدادي", 
              third: "الثالث الإعدادي",
              firstSecondary: "الأول الثانوي"
            }
            const gradeExams = exams.filter(exam => exam.isActive && exam.grade === gradeMapping[grade])
            const gradeNames = gradeMapping
            
            return (
              <TabsContent key={grade} value={grade} className="space-y-4">
                {gradeExams.length === 0 ? (
                  <Card>
                    <CardContent className="text-center py-12">
                      <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        لا توجد اختبارات متاحة للصف {gradeNames[grade]}
                      </h3>
                      <p className="text-gray-500">لا توجد اختبارات نشطة لهذا الصف في الوقت الحالي</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid gap-4">
                    {gradeExams.map((exam) => (
                      <Card key={exam.id} className="hover:shadow-md transition-shadow">
                        <CardHeader>
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <CardTitle className="text-xl mb-2">{exam.title}</CardTitle>
                              <CardDescription className="mb-3">{exam.description}</CardDescription>
                              <div className="flex gap-4 text-sm text-gray-600">
                                <div className="flex items-center gap-1">
                                  <FileText className="h-4 w-4" />
                                  {exam.questions.length} سؤال
                                </div>
                                <div className="flex items-center gap-1">
                                  <Clock className="h-4 w-4" />
                                  {exam.duration} دقيقة
                                </div>
                                <div className="flex items-center gap-1">
                                  <GraduationCap className="h-4 w-4" />
                                  {gradeNames[exam.grade]}
                                </div>
                              </div>
                            </div>
                            <Button onClick={() => startExam(exam)} className="bg-blue-600 hover:bg-blue-700">
                              بدء الاختبار
                            </Button>
                          </div>
                        </CardHeader>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            )
          })}
        </Tabs>
      </div>

      {/* Result Dialog */}
      <Dialog open={showResultDialog} onOpenChange={setShowResultDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl text-center">نتيجة الاختبار</DialogTitle>
            <DialogDescription className="text-center">
              {examResult?.examTitle}
            </DialogDescription>
          </DialogHeader>
          
          {examResult && (
            <div className="space-y-6">
              {/* Score Display */}
              <div className="text-center">
                {examResult.score > 70 && (
                  <div className="mb-4 p-4 bg-gradient-to-r from-green-100 to-blue-100 rounded-lg border-2 border-green-300">
                    <h3 className="text-2xl font-bold text-green-700 mb-2">🎉 أحسنت أيها البطل! 🎉</h3>
                    <p className="text-lg text-green-600 font-semibold">طلاب البروفيسير دائماً في المقدمة</p>
                  </div>
                )}
                <div className={`text-6xl font-bold mb-2 ${getScoreColor(examResult.score)}`}>
                  {examResult.score}%
                </div>
                <div className="flex justify-center mb-4">
                  <Badge variant={getScoreBadge(examResult.score).variant} className="text-lg px-4 py-2">
                    {getScoreBadge(examResult.score).icon} {getScoreBadge(examResult.score).text}
                  </Badge>
                </div>
                <p className="text-gray-600">
                  {examResult.correctAnswers} من {examResult.totalQuestions} إجابة صحيحة
                </p>
              </div>

              {/* Detailed Results */}
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {examResult.answers.map((answer, index) => (
                  <div key={index} className={`p-3 rounded-lg border ${
                    answer.isCorrect ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
                  }`}>
                    <div className="flex items-start gap-2">
                      {answer.isCorrect ? (
                        <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-600 mt-0.5" />
                      )}
                      <div className="flex-1">
                        <p className="font-medium mb-1">{answer.questionText}</p>
                        <p className="text-sm text-gray-600">
                          إجابتك: {answer.options[answer.studentAnswer] || 'لم تجب'}
                        </p>
                        {!answer.isCorrect && (
                          <p className="text-sm text-green-600">
                            الإجابة الصحيحة: {answer.options[answer.correctAnswer]}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button onClick={resetExam} className="w-full">
              العودة للاختبارات
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Student Name Dialog */}
      <Dialog open={showNameDialog} onOpenChange={setShowNameDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">أدخل اسمك</DialogTitle>
            <DialogDescription className="text-center">
              الرجاء إدخال اسمك قبل بدء الاختبار
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="studentName">الاسم</Label>
              <Input
                id="studentName"
                type="text"
                placeholder="أدخل اسمك الكامل"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && studentName.trim()) {
                    handleNameSubmit()
                  }
                }}
                autoFocus
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              onClick={handleNameSubmit} 
              disabled={!studentName.trim()}
              className="w-full"
            >
              بدء الاختبار
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Password Dialog */}
      <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">كلمة سر الاختبار</DialogTitle>
            <DialogDescription className="text-center">
              هذا الاختبار محمي بكلمة سر. الرجاء إدخال كلمة السر للمتابعة
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="examPassword">كلمة السر</Label>
              <Input
                id="examPassword"
                type="password"
                placeholder="أدخل كلمة سر الاختبار"
                value={examPassword}
                onChange={(e) => setExamPassword(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && examPassword.trim()) {
                    handlePasswordSubmit()
                  }
                }}
                autoFocus
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              onClick={handlePasswordSubmit} 
              disabled={!examPassword.trim()}
              className="w-full"
            >
              تأكيد
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default StudentInterface

