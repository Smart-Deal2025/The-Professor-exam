import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Checkbox } from '@/components/ui/checkbox.jsx'
import { Plus, FileText, Clock, Users, Eye, Trash2, Lock } from 'lucide-react'

const ExamCreator = ({ questions, exams, setExams, examsAPI }) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [selectedQuestions, setSelectedQuestions] = useState([])
  const [examForm, setExamForm] = useState({
    title: '',
    description: '',
    duration: 30,
    subject: '',
    difficulty: 'متوسط',
    grade: 'الأول الإعدادي',
    password: '' // New field for exam password
  })

  const resetForm = () => {
    setExamForm({
      title: '',
      description: '',
      duration: 30,
      subject: '',
      difficulty: 'متوسط',
      grade: 'الأول الإعدادي',
      password: '' // Reset password field
    })
    setSelectedQuestions([])
  }

  const handleQuestionToggle = (questionId) => {
    setSelectedQuestions(prev => 
      prev.includes(questionId)
        ? prev.filter(id => id !== questionId)
        : [...prev, questionId]
    )
  }

  const handleCreateExam = async () => {
    if (!examForm.title.trim() || selectedQuestions.length === 0) {
      alert('يرجى ملء عنوان الاختبار واختيار أسئلة على الأقل')
      return
    }

    const newExam = {
      title: examForm.title,
      description: examForm.description,
      duration: parseInt(examForm.duration),
      subject: examForm.subject,
      difficulty: examForm.difficulty,
      grade: examForm.grade,
      password: examForm.password, // Include password
      questionIds: selectedQuestions,
      questionCount: selectedQuestions.length
    }

    try {
      if (examsAPI) {
        const createdExam = await examsAPI.create(newExam)
        setExams(prev => [...prev, createdExam])
      } else {
        // Fallback to localStorage
        const examWithId = { ...newExam, id: Date.now(), createdAt: new Date().toISOString(), isActive: true }
        const updatedExams = [...exams, examWithId]
        setExams(updatedExams)
        localStorage.setItem('science-quiz-exams', JSON.stringify(updatedExams))
      }
      
      alert('تم إنشاء الاختبار بنجاح!')
      setIsDialogOpen(false)
      resetForm()
    } catch (error) {
      console.error('Error creating exam:', error)
      alert('حدث خطأ أثناء إنشاء الاختبار')
    }
  }

  const handleDeleteExam = (examId) => {
    if (confirm('هل أنت متأكد من حذف هذا الاختبار؟')) {
      const updatedExams = exams.filter(exam => exam.id !== examId)
      setExams(updatedExams)
      localStorage.setItem('science-quiz-exams', JSON.stringify(updatedExams))
    }
  }

  const filteredQuestions = questions.filter(q => {
    if (examForm.subject && q.subject !== examForm.subject) return false
    if (examForm.difficulty !== 'الكل' && q.difficulty !== examForm.difficulty) return false
    return true
  })

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">إنشاء الاختبارات</h2>
          <p className="text-gray-600">إنشاء اختبارات جديدة من بنك الأسئلة المتاح</p>
        </div>
        <Button 
          onClick={() => setIsDialogOpen(true)}
          className="bg-purple-600 hover:bg-purple-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          إنشاء اختبار جديد
        </Button>
      </div>

      {/* قائمة الاختبارات */}
      {exams.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">لا توجد اختبارات</h3>
            <p className="text-gray-600 mb-4">ابدأ بإنشاء اختبار جديد من بنك الأسئلة المتاح</p>
            <Button 
              onClick={() => setIsDialogOpen(true)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              إنشاء اختبار جديد
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {exams.map((exam) => (
            <Card key={exam.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{exam.title}</CardTitle>
                    <CardDescription>{exam.description}</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeleteExam(exam.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2 mb-3">
                  <Badge variant="secondary">
                    <Clock className="w-3 h-3 mr-1" />
                    {exam.duration} دقيقة
                  </Badge>
                  <Badge variant="secondary">
                    <FileText className="w-3 h-3 mr-1" />
                    {exam.questions.length} سؤال
                  </Badge>
                  <Badge variant="secondary">{exam.subject}</Badge>
                  <Badge variant="secondary">{exam.difficulty}</Badge>
                  <Badge variant="secondary">{exam.grade}</Badge>
                </div>
                <p className="text-sm text-gray-600">
                  تم الإنشاء: {new Date(exam.createdAt).toLocaleDateString('ar-EG')}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* نافذة إنشاء اختبار */}
      {isDialogOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">إنشاء اختبار جديد</h3>
              <Button
                variant="outline"
                onClick={() => {
                  setIsDialogOpen(false)
                  resetForm()
                }}
              >
                إلغاء
              </Button>
            </div>

            <div className="space-y-4">
              {/* معلومات الاختبار */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">عنوان الاختبار *</Label>
                  <Input
                    id="title"
                    value={examForm.title}
                    onChange={(e) => setExamForm({...examForm, title: e.target.value})}
                    placeholder="مثال: اختبار الكيمياء - الوحدة الأولى"
                  />
                </div>
                <div>
                  <Label htmlFor="duration">مدة الاختبار (بالدقائق)</Label>
                  <Input
                    id="duration"
                    type="number"
                    value={examForm.duration}
                    onChange={(e) => setExamForm({...examForm, duration: e.target.value})}
                    min="5"
                    max="180"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="password">كلمة سر الاختبار (اختيارية)</Label>
                <Input
                  id="password"
                  type="password"
                  value={examForm.password}
                  onChange={(e) => setExamForm({...examForm, password: e.target.value})}
                  placeholder="اتركها فارغة إذا لم تكن تريد كلمة سر"
                />
                <p className="text-sm text-gray-500 mt-1">
                  إذا تم تعيين كلمة سر، سيُطلب من الطلاب إدخالها قبل بدء الاختبار
                </p>
              </div>

              <div>
                <Label htmlFor="description">وصف الاختبار</Label>
                <Textarea
                  id="description"
                  value={examForm.description}
                  onChange={(e) => setExamForm({...examForm, description: e.target.value})}
                  placeholder="وصف مختصر للاختبار..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="subject">المادة</Label>
                  <Input
                    id="subject"
                    value={examForm.subject}
                    onChange={(e) => setExamForm({...examForm, subject: e.target.value})}
                    placeholder="مثال: الكيمياء"
                  />
                </div>
                <div>
                  <Label htmlFor="difficulty">مستوى الصعوبة</Label>
                  <select
                    id="difficulty"
                    value={examForm.difficulty}
                    onChange={(e) => setExamForm({...examForm, difficulty: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value="سهل">سهل</option>
                    <option value="متوسط">متوسط</option>
                    <option value="صعب">صعب</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="grade">الصف الدراسي</Label>
                  <select
                    id="grade"
                    value={examForm.grade}
                    onChange={(e) => setExamForm({...examForm, grade: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value="الأول الإعدادي">الأول الإعدادي</option>
                    <option value="الثاني الإعدادي">الثاني الإعدادي</option>
                    <option value="الثالث الإعدادي">الثالث الإعدادي</option>
                    <option value="الأول الثانوي">الأول الثانوي</option>
                  </select>
                </div>
              </div>

              {/* اختيار الأسئلة */}
              <div>
                <Label>اختيار الأسئلة ({selectedQuestions.length} مختار)</Label>
                <div className="max-h-60 overflow-y-auto border border-gray-200 rounded-md p-4 space-y-2">
                  {filteredQuestions.length === 0 ? (
                    <p className="text-gray-500 text-center">لا توجد أسئلة متاحة</p>
                  ) : (
                    filteredQuestions.map((question) => (
                      <div key={question.id} className="flex items-start space-x-2 p-2 border rounded">
                        <Checkbox
                          checked={selectedQuestions.includes(question.id)}
                          onCheckedChange={() => handleQuestionToggle(question.id)}
                        />
                        <div className="flex-1">
                          <p className="font-medium">{question.text}</p>
                          <div className="flex gap-2 mt-1">
                            <Badge variant="outline" className="text-xs">{question.subject}</Badge>
                            <Badge variant="outline" className="text-xs">{question.difficulty}</Badge>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsDialogOpen(false)
                    resetForm()
                  }}
                >
                  إلغاء
                </Button>
                <Button
                  onClick={handleCreateExam}
                  className="bg-purple-600 hover:bg-purple-700"
                  disabled={!examForm.title.trim() || selectedQuestions.length === 0}
                >
                  إنشاء الاختبار
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default ExamCreator

