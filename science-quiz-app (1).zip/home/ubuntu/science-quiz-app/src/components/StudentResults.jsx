import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { BarChart3, TrendingUp, Users, Award, Download, Eye } from 'lucide-react'

const StudentResults = ({ results }) => {
  const [selectedExam, setSelectedExam] = useState('all')
  const [selectedStudent, setSelectedStudent] = useState('all')

  const filteredResults = results.filter(result => {
    const matchesExam = selectedExam === 'all' || result.examTitle === selectedExam
    const matchesStudent = selectedStudent === 'all' || result.studentName === selectedStudent
    return matchesExam && matchesStudent
  })

  const uniqueExams = [...new Set(results.map(r => r.examTitle))]
  const uniqueStudents = [...new Set(results.map(r => r.studentName))]

  // Statistics
  const averageScore = results.length > 0 
    ? (results.reduce((sum, result) => sum + result.score, 0) / results.length).toFixed(1)
    : 0

  const highestScore = results.length > 0 
    ? Math.max(...results.map(r => r.score))
    : 0

  const totalAttempts = results.length

  const passRate = results.length > 0
    ? ((results.filter(r => r.score >= 60).length / results.length) * 100).toFixed(1)
    : 0

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600'
    if (score >= 80) return 'text-blue-600'
    if (score >= 70) return 'text-yellow-600'
    if (score >= 60) return 'text-orange-600'
    return 'text-red-600'
  }

  const getScoreBadge = (score) => {
    if (score >= 90) return { variant: 'default', text: 'ممتاز' }
    if (score >= 80) return { variant: 'secondary', text: 'جيد جداً' }
    if (score >= 70) return { variant: 'outline', text: 'جيد' }
    if (score >= 60) return { variant: 'secondary', text: 'مقبول' }
    return { variant: 'destructive', text: 'ضعيف' }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">النتائج والتقارير</h2>
          <p className="text-gray-600">عرض وتحليل نتائج الطلاب في الاختبارات</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            تصدير التقرير
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المحاولات</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalAttempts}</div>
            <p className="text-xs text-muted-foreground">
              عبر جميع الاختبارات
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">متوسط الدرجات</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageScore}%</div>
            <p className="text-xs text-muted-foreground">
              من إجمالي الدرجات
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">أعلى درجة</CardTitle>
            <Award className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{highestScore}%</div>
            <p className="text-xs text-muted-foreground">
              أفضل أداء مسجل
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">معدل النجاح</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{passRate}%</div>
            <p className="text-xs text-muted-foreground">
              نسبة الطلاب الناجحين
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">تصفية النتائج</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">تصفية حسب الاختبار</label>
              <Select value={selectedExam} onValueChange={setSelectedExam}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الاختبارات</SelectItem>
                  {uniqueExams.map(exam => (
                    <SelectItem key={exam} value={exam}>{exam}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">تصفية حسب الطالب</label>
              <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الطلاب</SelectItem>
                  {uniqueStudents.map(student => (
                    <SelectItem key={student} value={student}>{student}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results List */}
      <div className="space-y-4">
        {filteredResults.map((result) => {
          const scoreBadge = getScoreBadge(result.score)
          return (
            <Card key={result.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <CardTitle className="text-lg">{result.studentName}</CardTitle>
                      <Badge variant={scoreBadge.variant}>
                        {scoreBadge.text}
                      </Badge>
                    </div>
                    <CardDescription className="mb-3">{result.examTitle}</CardDescription>
                    <div className="flex gap-6 text-sm text-gray-600">
                      <span>تاريخ الاختبار: {new Date(result.completedAt).toLocaleDateString('ar-SA')}</span>
                      <span>الوقت المستغرق: {result.timeSpent} دقيقة</span>
                      <span>الإجابات الصحيحة: {result.correctAnswers}/{result.totalQuestions}</span>
                    </div>
                  </div>
                  <div className="text-left">
                    <div className={`text-3xl font-bold ${getScoreColor(result.score)}`}>
                      {result.score}%
                    </div>
                    <Button variant="outline" size="sm" className="mt-2">
                      <Eye className="h-4 w-4 mr-1" />
                      التفاصيل
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>التقدم في الاختبار</span>
                    <span>{result.score}%</span>
                  </div>
                  <Progress value={result.score} className="h-2" />
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {filteredResults.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">لا توجد نتائج</h3>
            <p className="text-gray-500">لا توجد نتائج تطابق معايير التصفية المحددة</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default StudentResults

