import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Plus, Edit, Trash2, Search } from 'lucide-react'

const QuestionManager = ({ questions, setQuestions }) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingQuestion, setEditingQuestion] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterSubject, setFilterSubject] = useState('all')
  const [filterDifficulty, setFilterDifficulty] = useState('all')
  
  const [formData, setFormData] = useState({
    text: '',
    type: 'multiple-choice',
    questionType: 'text', // 'text' or 'image'
    imageUrl: '',
    options: ['', '', '', ''],
    correctAnswer: 0,
    subject: '',
    unit: '',
    difficulty: 'متوسط'
  })

  const resetForm = () => {
    setFormData({
      text: '',
      type: 'multiple-choice',
      questionType: 'text',
      imageUrl: '',
      options: ['', '', '', ''],
      correctAnswer: 0,
      subject: '',
      unit: '',
      difficulty: 'متوسط'
    })
    setEditingQuestion(null)
  }

  const handleImageUpload = (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setFormData({...formData, imageUrl: e.target.result})
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    
    // التحقق من صحة البيانات
    if (formData.questionType === 'text' && !formData.text.trim()) {
      alert('يرجى إدخال نص السؤال')
      return
    }
    
    if (formData.questionType === 'image' && !formData.imageUrl) {
      alert('يرجى اختيار صورة للسؤال')
      return
    }
    
    if (editingQuestion) {
      setQuestions(questions.map(q => 
        q.id === editingQuestion.id 
          ? { ...formData, id: editingQuestion.id }
          : q
      ))
    } else {
      const newQuestion = {
        ...formData,
        id: Date.now()
      }
      setQuestions([...questions, newQuestion])
    }
    
    resetForm()
    setIsDialogOpen(false)
  }

  const handleEdit = (question) => {
    setFormData(question)
    setEditingQuestion(question)
    setIsDialogOpen(true)
  }

  const handleDelete = (id) => {
    setQuestions(questions.filter(q => q.id !== id))
  }

  const filteredQuestions = questions.filter(question => {
    const matchesSearch = question.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         question.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         question.unit.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesSubject = filterSubject === 'all' || question.subject === filterSubject
    const matchesDifficulty = filterDifficulty === 'all' || question.difficulty === filterDifficulty
    
    return matchesSearch && matchesSubject && matchesDifficulty
  })

  const subjects = [...new Set(questions.map(q => q.subject))]
  const difficulties = ['سهل', 'متوسط', 'صعب']

  return (
    <div className="space-y-6">
      {/* Header and Add Button */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">إدارة الأسئلة</h2>
          <p className="text-gray-600">إضافة وتعديل وحذف أسئلة بنك الأسئلة</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              إضافة سؤال جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingQuestion ? 'تعديل السؤال' : 'إضافة سؤال جديد'}
              </DialogTitle>
              <DialogDescription>
                املأ البيانات التالية لإضافة سؤال جديد إلى بنك الأسئلة
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="questionType">نوع السؤال</Label>
                <Select value={formData.questionType} onValueChange={(value) => setFormData({...formData, questionType: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="text">سؤال نصي</SelectItem>
                    <SelectItem value="image">سؤال بصورة</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.questionType === 'text' ? (
                <div className="space-y-2">
                  <Label htmlFor="text">نص السؤال</Label>
                  <Textarea
                    id="text"
                    value={formData.text}
                    onChange={(e) => setFormData({...formData, text: e.target.value})}
                    placeholder="اكتب نص السؤال هنا..."
                    required
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <Label htmlFor="image">صورة السؤال</Label>
                  <Input
                    id="image"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="cursor-pointer"
                  />
                  {formData.imageUrl && (
                    <div className="mt-2">
                      <img 
                        src={formData.imageUrl} 
                        alt="معاينة السؤال" 
                        className="max-w-full h-48 object-contain border rounded"
                      />
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="subject">المادة</Label>
                  <Input
                    id="subject"
                    value={formData.subject}
                    onChange={(e) => setFormData({...formData, subject: e.target.value})}
                    placeholder="مثال: الكيمياء"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="unit">الوحدة</Label>
                  <Input
                    id="unit"
                    value={formData.unit}
                    onChange={(e) => setFormData({...formData, unit: e.target.value})}
                    placeholder="مثال: العناصر الكيميائية"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="difficulty">مستوى الصعوبة</Label>
                <Select value={formData.difficulty} onValueChange={(value) => setFormData({...formData, difficulty: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="سهل">سهل</SelectItem>
                    <SelectItem value="متوسط">متوسط</SelectItem>
                    <SelectItem value="صعب">صعب</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.type === 'multiple-choice' && (
                <div className="space-y-4">
                  <Label>الخيارات</Label>
                  {formData.options.map((option, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Input
                        value={option}
                        onChange={(e) => {
                          const newOptions = [...formData.options]
                          newOptions[index] = e.target.value
                          setFormData({...formData, options: newOptions})
                        }}
                        placeholder={`الخيار ${index + 1}`}
                        required
                      />
                      <Button
                        type="button"
                        variant={formData.correctAnswer === index ? "default" : "outline"}
                        size="sm"
                        onClick={() => setFormData({...formData, correctAnswer: index})}
                      >
                        {formData.correctAnswer === index ? 'صحيح' : 'اختر'}
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  إلغاء
                </Button>
                <Button type="submit">
                  {editingQuestion ? 'تحديث السؤال' : 'إضافة السؤال'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">البحث والتصفية</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="search">البحث</Label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="search"
                  placeholder="ابحث في الأسئلة..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>تصفية حسب المادة</Label>
              <Select value={filterSubject} onValueChange={setFilterSubject}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع المواد</SelectItem>
                  {subjects.map(subject => (
                    <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>تصفية حسب الصعوبة</Label>
              <Select value={filterDifficulty} onValueChange={setFilterDifficulty}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع المستويات</SelectItem>
                  {difficulties.map(difficulty => (
                    <SelectItem key={difficulty} value={difficulty}>{difficulty}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Questions List */}
      <div className="grid gap-4">
        {filteredQuestions.map((question) => (
          <Card key={question.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  {question.questionType === 'image' ? (
                    <div className="mb-2">
                      <img 
                        src={question.imageUrl} 
                        alt="سؤال مصور" 
                        className="max-w-full h-32 object-contain border rounded mb-2"
                      />
                      {question.text && (
                        <CardTitle className="text-lg">{question.text}</CardTitle>
                      )}
                    </div>
                  ) : (
                    <CardTitle className="text-lg mb-2">{question.text}</CardTitle>
                  )}
                  <div className="flex gap-2 mb-2">
                    <Badge variant="secondary">{question.subject}</Badge>
                    <Badge variant="outline">{question.unit}</Badge>
                    <Badge variant={
                      question.difficulty === 'سهل' ? 'default' :
                      question.difficulty === 'متوسط' ? 'secondary' : 'destructive'
                    }>
                      {question.difficulty}
                    </Badge>
                    <Badge variant="outline">
                      {question.questionType === 'image' ? 'سؤال مصور' : 'سؤال نصي'}
                    </Badge>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(question)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDelete(question.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {question.type === 'multiple-choice' && (
                <div className="space-y-2">
                  {question.options.map((option, index) => (
                    <div
                      key={index}
                      className={`p-2 rounded border ${
                        index === question.correctAnswer
                          ? 'bg-green-50 border-green-200 text-green-800'
                          : 'bg-gray-50 border-gray-200'
                      }`}
                    >
                      {index + 1}. {option}
                      {index === question.correctAnswer && (
                        <span className="mr-2 text-green-600 font-semibold">✓</span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredQuestions.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-gray-500">لا توجد أسئلة تطابق معايير البحث</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default QuestionManager

