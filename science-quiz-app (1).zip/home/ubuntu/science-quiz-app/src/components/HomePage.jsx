import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { GraduationCap, User, BookOpen, Users } from 'lucide-react'

const HomePage = ({ onSelectRole }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
      <div className="container mx-auto p-6 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            البروفيسير في العلوم
          </h1>
          <p className="text-xl text-gray-600 mb-2">منصة تعليمية تفاعلية لإدارة الاختبارات والأسئلة</p>
          <p className="text-lg text-gray-500">اختر نوع الحساب للمتابعة</p>
        </div>

        {/* Role Selection Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {/* Student Portal */}
          <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer border-2 hover:border-blue-400">
            <CardHeader className="text-center pb-4">
              <div className="mx-auto mb-4 p-4 bg-blue-100 rounded-full w-20 h-20 flex items-center justify-center">
                <GraduationCap className="h-10 w-10 text-blue-600" />
              </div>
              <CardTitle className="text-2xl text-blue-800">بوابة الطالب</CardTitle>
              <CardDescription className="text-lg">
                ادخل للاختبارات والتقييمات
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <ul className="text-gray-600 mb-6 space-y-2">
                <li>• الوصول المباشر للاختبارات</li>
                <li>• اختبارات تفاعلية مع عداد زمني</li>
                <li>• نتائج فورية ومراجعة الإجابات</li>
                <li>• تصنيف حسب الصفوف الدراسية</li>
              </ul>
              <Button 
                onClick={() => onSelectRole('student')}
                className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-3"
                size="lg"
              >
                <Users className="h-5 w-5 mr-2" />
                دخول بوابة الطالب
              </Button>
            </CardContent>
          </Card>

          {/* Teacher Portal */}
          <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer border-2 hover:border-green-400">
            <CardHeader className="text-center pb-4">
              <div className="mx-auto mb-4 p-4 bg-green-100 rounded-full w-20 h-20 flex items-center justify-center">
                <User className="h-10 w-10 text-green-600" />
              </div>
              <CardTitle className="text-2xl text-green-800">بوابة المعلم</CardTitle>
              <CardDescription className="text-lg">
                إدارة الأسئلة والاختبارات
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <ul className="text-gray-600 mb-6 space-y-2">
                <li>• إدارة بنك الأسئلة</li>
                <li>• إنشاء اختبارات مخصصة</li>
                <li>• مراجعة النتائج والإحصائيات</li>
                <li>• تصدير واستيراد البيانات</li>
              </ul>
              <Button 
                onClick={() => onSelectRole('teacher')}
                className="w-full bg-green-600 hover:bg-green-700 text-lg py-3"
                size="lg"
              >
                <BookOpen className="h-5 w-5 mr-2" />
                دخول بوابة المعلم
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <div className="text-center mt-12">
          <p className="text-gray-500">
            منصة تعليمية متطورة لتحسين تجربة التعلم والتقييم
          </p>
        </div>
      </div>
    </div>
  )
}

export default HomePage

