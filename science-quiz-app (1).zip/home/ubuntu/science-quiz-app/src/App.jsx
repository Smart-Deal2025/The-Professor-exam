import { useState, useEffect } from 'react'
import HomePage from './components/HomePage'
import LoginScreen from './components/LoginScreen'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { BookOpen, Users, FileText, BarChart3, Settings, Plus, Download, Upload, Home } from 'lucide-react'
import QuestionManager from './components/QuestionManager'
import ExamCreator from './components/ExamCreator'
import StudentResults from './components/StudentResults'
import StudentInterface from './components/StudentInterface'
import { questionsAPI, examsAPI, resultsAPI, dataAPI } from './lib/api'
import './App.css'

function App() {
  const [userRole, setUserRole] = useState(null) // null, 'teacher' or 'student'
  const [isLoggedIn, setIsLoggedIn] = useState(false) // New state for login status
  const [activeTab, setActiveTab] = useState('questions') // للتبويبات
  const [questions, setQuestions] = useState([])
  const [exams, setExams] = useState([])
  const [results, setResults] = useState([])

  // Load data from API on component mount
  useEffect(() => {
    const loadData = async () => {
      try {
        const [questionsData, examsData, resultsData] = await Promise.all([
          questionsAPI.getAll(),
          examsAPI.getAll(),
          resultsAPI.getAll()
        ])
        setQuestions(questionsData)
        setExams(examsData)
        setResults(resultsData)
      } catch (error) {
        console.error('Error loading data:', error)
      }
    }
    loadData()
  }, [])

  const handleSubmitResult = async (result) => {
    try {
      const newResult = await resultsAPI.create(result)
      setResults(prev => [...prev, newResult])
    } catch (error) {
      console.error('Error saving result:', error)
    }
  }

  const handleLogin = () => {
    setIsLoggedIn(true)
  }

  const handleSelectRole = (role) => {
    setUserRole(role)
    if (role === 'student') {
      setIsLoggedIn(true) // Students don't need login
    }
  }

  const handleBackToHome = () => {
    setUserRole(null)
    setIsLoggedIn(false)
  }

  const handleExportData = async () => {
    try {
      const data = await dataAPI.export()
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `البروفيسير_في_العلوم_${new Date().toISOString().split('T')[0]}.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      alert('تم تصدير البيانات بنجاح!')
    } catch (error) {
      console.error('Error exporting data:', error)
      alert('حدث خطأ أثناء تصدير البيانات')
    }
  }

  const handleImportData = async (event) => {
    const file = event.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = async (e) => {
        try {
          const data = JSON.parse(e.target.result)
          await dataAPI.import(data)
          
          // Reload data after import
          const [questionsData, examsData, resultsData] = await Promise.all([
            questionsAPI.getAll(),
            examsAPI.getAll(),
            resultsAPI.getAll()
          ])
          setQuestions(questionsData)
          setExams(examsData)
          setResults(resultsData)
          alert('تم استيراد البيانات بنجاح!')
        } catch (error) {
          console.error('Error importing data:', error)
          alert('حدث خطأ أثناء استيراد البيانات. تأكد من صحة الملف.')
        }
      }
      reader.readAsText(file)
    }
    // Reset file input
    event.target.value = ''
  }

  // Show home page if no role selected
  if (!userRole) {
    return <HomePage onSelectRole={handleSelectRole} />
  }

  // Show login screen for teachers
  if (userRole === 'teacher' && !isLoggedIn) {
    return <LoginScreen onLogin={handleLogin} />
  }

  if (userRole === 'student') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <StudentInterface 
          questions={questions}
          exams={exams}
          onSubmitResult={handleSubmitResult}
          onBackToHome={handleBackToHome}
        />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">
                البروفيسير في العلوم
              </h1>
              <p className="text-gray-600">منصة تعليمية تفاعلية لإدارة الاختبارات والأسئلة</p>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={handleBackToHome}
                className="flex items-center gap-2"
              >
                <Home className="h-4 w-4" />
                الصفحة الرئيسية
              </Button>
              <input
                type="file"
                accept=".json"
                onChange={handleImportData}
                style={{ display: 'none' }}
                id="import-file"
              />
              <Button 
                variant="outline"
                onClick={() => document.getElementById('import-file').click()}
                className="flex items-center gap-2"
              >
                <Upload className="h-4 w-4" />
                استيراد البيانات
              </Button>
              <Button 
                onClick={handleExportData}
                className="flex items-center gap-2"
              >
                <Download className="h-4 w-4" />
                تصدير البيانات
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">إجمالي الأسئلة</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{questions.length}</div>
              <p className="text-xs text-muted-foreground">
                +2 من الأسبوع الماضي
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">الاختبارات النشطة</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{exams.length}</div>
              <p className="text-xs text-muted-foreground">
                +1 من الأسبوع الماضي
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">الطلاب المسجلين</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">45</div>
              <p className="text-xs text-muted-foreground">
                +5 من الأسبوع الماضي
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">متوسط الدرجات</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">85%</div>
              <p className="text-xs text-muted-foreground">
                +2% من الأسبوع الماضي
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Simple Tabs System */}
        <div className="mb-8">
          <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
            <button
              onClick={() => setActiveTab('questions')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors ${
                activeTab === 'questions' 
                  ? 'bg-white text-blue-600 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <BookOpen className="h-4 w-4" />
              إدارة الأسئلة
            </button>
            <button
              onClick={() => setActiveTab('exams')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors ${
                activeTab === 'exams' 
                  ? 'bg-white text-blue-600 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <FileText className="h-4 w-4" />
              إنشاء الاختبارات
            </button>
            <button
              onClick={() => setActiveTab('results')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors ${
                activeTab === 'results' 
                  ? 'bg-white text-blue-600 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <BarChart3 className="h-4 w-4" />
              النتائج والتقارير
            </button>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'questions' && (
          <QuestionManager 
            questions={questions}
            setQuestions={setQuestions}
            questionsAPI={questionsAPI}
          />
        )}
        
        {activeTab === 'exams' && (
          <ExamCreator 
            questions={questions}
            exams={exams}
            setExams={setExams}
            examsAPI={examsAPI}
          />
        )}
        
        {activeTab === 'results' && (
          <StudentResults results={results} />
        )}
      </div>
    </div>
  )
}

export default App

