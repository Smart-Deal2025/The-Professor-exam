from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
import json
from src.models.quiz import db, Question, Exam, Result

quiz_bp = Blueprint('quiz', __name__)

# Questions endpoints
@quiz_bp.route('/questions', methods=['GET'])
@cross_origin()
def get_questions():
    try:
        questions = Question.query.all()
        return jsonify([q.to_dict() for q in questions]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@quiz_bp.route('/questions', methods=['POST'])
@cross_origin()
def create_question():
    try:
        data = request.get_json()
        question = Question.from_dict(data)
        db.session.add(question)
        db.session.commit()
        return jsonify(question.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@quiz_bp.route('/questions/<int:question_id>', methods=['PUT'])
@cross_origin()
def update_question(question_id):
    try:
        question = Question.query.get_or_404(question_id)
        data = request.get_json()
        
        question.text = data.get('text', question.text)
        question.type = data.get('type', question.type)
        question.options = json.dumps(data.get('options', json.loads(question.options)))
        question.correct_answer = data.get('correctAnswer', question.correct_answer)
        question.subject = data.get('subject', question.subject)
        question.unit = data.get('unit', question.unit)
        question.difficulty = data.get('difficulty', question.difficulty)
        question.grade = data.get('grade', question.grade)
        
        db.session.commit()
        return jsonify(question.to_dict()), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@quiz_bp.route('/questions/<int:question_id>', methods=['DELETE'])
@cross_origin()
def delete_question(question_id):
    try:
        question = Question.query.get_or_404(question_id)
        db.session.delete(question)
        db.session.commit()
        return jsonify({'message': 'Question deleted successfully'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Exams endpoints
@quiz_bp.route('/exams', methods=['GET'])
@cross_origin()
def get_exams():
    try:
        exams = Exam.query.all()
        return jsonify([e.to_dict() for e in exams]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@quiz_bp.route('/exams', methods=['POST'])
@cross_origin()
def create_exam():
    try:
        data = request.get_json()
        exam = Exam.from_dict(data)
        db.session.add(exam)
        db.session.commit()
        return jsonify(exam.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@quiz_bp.route('/exams/<int:exam_id>', methods=['PUT'])
@cross_origin()
def update_exam(exam_id):
    try:
        exam = Exam.query.get_or_404(exam_id)
        data = request.get_json()
        
        exam.title = data.get('title', exam.title)
        exam.description = data.get('description', exam.description)
        exam.grade = data.get('grade', exam.grade)
        exam.subject = data.get('subject', exam.subject)
        exam.difficulty = data.get('difficulty', exam.difficulty)
        exam.duration = data.get('duration', exam.duration)
        exam.question_count = data.get('questionCount', exam.question_count)
        exam.password = data.get('password', exam.password)
        exam.question_ids = json.dumps(data.get('questionIds', json.loads(exam.question_ids)))
        
        db.session.commit()
        return jsonify(exam.to_dict()), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@quiz_bp.route('/exams/<int:exam_id>', methods=['DELETE'])
@cross_origin()
def delete_exam(exam_id):
    try:
        exam = Exam.query.get_or_404(exam_id)
        db.session.delete(exam)
        db.session.commit()
        return jsonify({'message': 'Exam deleted successfully'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@quiz_bp.route('/exams/<int:exam_id>/verify-password', methods=['POST'])
@cross_origin()
def verify_exam_password(exam_id):
    try:
        exam = Exam.query.get_or_404(exam_id)
        data = request.get_json()
        password = data.get('password')
        
        if exam.password and exam.password != password:
            return jsonify({'valid': False, 'message': 'كلمة السر غير صحيحة'}), 200
        
        return jsonify({'valid': True, 'message': 'كلمة السر صحيحة'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Results endpoints
@quiz_bp.route('/results', methods=['GET'])
@cross_origin()
def get_results():
    try:
        results = Result.query.all()
        return jsonify([r.to_dict() for r in results]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@quiz_bp.route('/results', methods=['POST'])
@cross_origin()
def create_result():
    try:
        data = request.get_json()
        result = Result.from_dict(data)
        db.session.add(result)
        db.session.commit()
        return jsonify(result.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Data export/import endpoints
@quiz_bp.route('/export', methods=['GET'])
@cross_origin()
def export_data():
    try:
        questions = Question.query.all()
        exams = Exam.query.all()
        results = Result.query.all()
        
        data = {
            'questions': [q.to_dict() for q in questions],
            'exams': [e.to_dict() for e in exams],
            'results': [r.to_dict() for r in results]
        }
        
        return jsonify(data), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@quiz_bp.route('/import', methods=['POST'])
@cross_origin()
def import_data():
    try:
        data = request.get_json()
        
        # Clear existing data
        Result.query.delete()
        Exam.query.delete()
        Question.query.delete()
        
        # Import questions
        if 'questions' in data:
            for q_data in data['questions']:
                question = Question.from_dict(q_data)
                db.session.add(question)
        
        # Import exams
        if 'exams' in data:
            for e_data in data['exams']:
                exam = Exam.from_dict(e_data)
                db.session.add(exam)
        
        # Import results
        if 'results' in data:
            for r_data in data['results']:
                result = Result.from_dict(r_data)
                db.session.add(result)
        
        db.session.commit()
        return jsonify({'message': 'Data imported successfully'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

