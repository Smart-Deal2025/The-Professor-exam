from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class Question(db.Model):
    __tablename__ = 'questions'
    
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(50), nullable=False, default='multiple-choice')
    options = db.Column(db.Text, nullable=False)  # JSON string
    correct_answer = db.Column(db.Integer, nullable=False)
    subject = db.Column(db.String(100), nullable=False)
    unit = db.Column(db.String(100), nullable=False)
    difficulty = db.Column(db.String(50), nullable=False)
    grade = db.Column(db.String(50), nullable=False, default='first')  # first, second, third, firstSecondary
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'text': self.text,
            'type': self.type,
            'options': json.loads(self.options) if self.options else [],
            'correctAnswer': self.correct_answer,
            'subject': self.subject,
            'unit': self.unit,
            'difficulty': self.difficulty,
            'grade': self.grade,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    @staticmethod
    def from_dict(data):
        return Question(
            text=data.get('text'),
            type=data.get('type', 'multiple-choice'),
            options=json.dumps(data.get('options', [])),
            correct_answer=data.get('correctAnswer'),
            subject=data.get('subject'),
            unit=data.get('unit'),
            difficulty=data.get('difficulty'),
            grade=data.get('grade', 'first')
        )

class Exam(db.Model):
    __tablename__ = 'exams'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    grade = db.Column(db.String(50), nullable=False)
    subject = db.Column(db.String(100), nullable=False)
    difficulty = db.Column(db.String(50), nullable=False)
    duration = db.Column(db.Integer, nullable=False)  # in minutes
    question_count = db.Column(db.Integer, nullable=False)
    password = db.Column(db.String(100))  # New field for exam password
    question_ids = db.Column(db.Text, nullable=False)  # JSON string of question IDs
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'grade': self.grade,
            'subject': self.subject,
            'difficulty': self.difficulty,
            'duration': self.duration,
            'questionCount': self.question_count,
            'password': self.password,
            'questionIds': json.loads(self.question_ids) if self.question_ids else [],
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    @staticmethod
    def from_dict(data):
        return Exam(
            title=data.get('title'),
            description=data.get('description'),
            grade=data.get('grade'),
            subject=data.get('subject'),
            difficulty=data.get('difficulty'),
            duration=data.get('duration'),
            question_count=data.get('questionCount'),
            password=data.get('password'),
            question_ids=json.dumps(data.get('questionIds', []))
        )

class Result(db.Model):
    __tablename__ = 'results'
    
    id = db.Column(db.Integer, primary_key=True)
    student_name = db.Column(db.String(100), nullable=False)
    exam_title = db.Column(db.String(200), nullable=False)
    exam_id = db.Column(db.Integer, db.ForeignKey('exams.id'), nullable=False)
    score = db.Column(db.Float, nullable=False)
    total_questions = db.Column(db.Integer, nullable=False)
    correct_answers = db.Column(db.Float, nullable=False)
    time_spent = db.Column(db.Integer, nullable=False)  # in minutes
    answers = db.Column(db.Text, nullable=False)  # JSON string
    completed_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'studentName': self.student_name,
            'examTitle': self.exam_title,
            'examId': self.exam_id,
            'score': self.score,
            'totalQuestions': self.total_questions,
            'correctAnswers': self.correct_answers,
            'timeSpent': self.time_spent,
            'answers': json.loads(self.answers) if self.answers else [],
            'completedAt': self.completed_at.isoformat() if self.completed_at else None
        }
    
    @staticmethod
    def from_dict(data):
        return Result(
            student_name=data.get('studentName'),
            exam_title=data.get('examTitle'),
            exam_id=data.get('examId'),
            score=data.get('score'),
            total_questions=data.get('totalQuestions'),
            correct_answers=data.get('correctAnswers'),
            time_spent=data.get('timeSpent'),
            answers=json.dumps(data.get('answers', []))
        )

